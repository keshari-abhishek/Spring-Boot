package com.abhi.springbootreference;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReferenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReferenceApplication.class, args);
	}

}
