package com.abhi.springbootreference;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootReferenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
