package com.abhi.SpringBootAI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAiApplication.class, args);
	}

}
