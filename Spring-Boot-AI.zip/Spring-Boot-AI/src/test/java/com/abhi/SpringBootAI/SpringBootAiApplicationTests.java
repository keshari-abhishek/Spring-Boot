package com.abhi.SpringBootAI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
